package com.epam.finaltest;

// public class Rx100 extends Yamaha {} --> getting error as final keyword from Yamaha class. so Final class can not be extended.
