package com.epam.finaltest;

public final class Yamaha extends Bike{
	
	//public final void ride(){}  --> Getting Error as remove final from ride. So final method can not override.

	public static void main(String[] args) {
		
		
	}

}
