package com.epam.accessmodifierstest;

public class Modifier {
	
	private int eno;
	String ename;
	protected int salary;
	public String deptarment;
	
	protected void display() 
    { 
        System.out.println("GeeksforGeeks"); 
    } 
	

}
