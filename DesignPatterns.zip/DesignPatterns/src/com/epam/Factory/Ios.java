package com.epam.Factory;

public class Ios implements OS{

	@Override
	public void spec() {
		System.out.println("IOS");
		
	}
	

}
