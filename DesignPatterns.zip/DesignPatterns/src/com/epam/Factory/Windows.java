package com.epam.Factory;

public class Windows implements OS{

	@Override
	public void spec() {
		System.out.println("Windows");	
	}

}
