package com.epam.Factory;

public interface OS {
	public void spec();
}
