package com.epam.Factory;

public class Android implements OS {

	@Override
	public void spec() {
		System.out.println("Andriod");		
	}

}
