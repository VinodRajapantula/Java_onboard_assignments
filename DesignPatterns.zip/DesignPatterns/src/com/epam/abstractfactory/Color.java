package com.epam.abstractfactory;

public interface Color {
	void fill();
}
