package com.epam.abstractfactory;

public interface Shape {
	void draw();
}
