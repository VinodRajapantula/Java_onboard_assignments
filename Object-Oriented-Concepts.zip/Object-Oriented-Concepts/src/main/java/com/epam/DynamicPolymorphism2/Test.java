package com.epam.DynamicPolymorphism2;

public class Test {

	public static void main(String[] args) {
		Animal animal = new Dog();
		animal.bark();
	}

}
