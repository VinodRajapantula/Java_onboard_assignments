package com.epam.DynamicPolymorphism1;

public class Circle implements Draw {

	public void draw() {
		System.out.println("Drawing circle");
	}

}
