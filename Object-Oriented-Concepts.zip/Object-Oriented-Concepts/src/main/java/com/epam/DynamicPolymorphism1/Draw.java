package com.epam.DynamicPolymorphism1;

public interface Draw {
		void draw();
}
